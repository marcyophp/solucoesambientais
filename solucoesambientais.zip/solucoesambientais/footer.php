<footer id="footer" class="footer">

  <div class="container">
    <div class="row gy-4">
      <div class="col-lg-5 col-md-12 footer-info">
        <a href="index.html" class="logo d-flex align-items-center">
          <span>SOLUÇÕES AMBIENTAIS</span>
        </a>
        <p>Possui alguma questionamento sobre algum serviço da Soluções Ambientais? Entre em contato agora mesmo e teremos o prazer de esclarecer.</p>
        <div class="social-links d-flex mt-4">
          <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
          <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
          <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
          <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
        </div>
      </div>

      <div class="col-lg-2 col-6 footer-links">
        <h4>Navegue</h4>
        <ul>
          <li><a href="#hero">Home</a></li>
          <li><a href="#sobre">Sobre</a></li>
          <li><a href="#servicos">Serviços</a></li>
          <li><a href="#projetos">Projetos</a></li>
          <li><a href="blog.html">Blog</a></li>
          <li><a href="#equipe">Equipe</a></li>
          <li><a href="#faq">FAQ</a></li>
          <li><a href="#fale">Fale conosco</a></li>
        </ul>
      </div>

      <div class="col-lg-2 col-6 footer-links">
        <h4>Outros serviços</h4>
        <ul>
          <li><a href="#">Estudos Ambientais</a></li>
          <li><a href="#">Laudos Técnicos Ambientais</a></li>
          <li><a href="#">Planos/Projetos Ambientais</a></li>
          <li><a href="#">Monitoramentos Ambientais</a></li>
          <li><a href="#">Assessoria Ambiental</a></li>
          <li><a href="#">Palestras Ambientais</a></li>
          <li><a href="#">Availiações/Supervisão Ambiental</a></li>
          <li><a href="#">CAR – Cadastro Ambiental Rural</a></li>
        </ul>
      </div>

      <div class="col-lg-3 col-md-12 footer-contact text-center text-md-start">
        <h4>Entre em contato</h4>
        <p>
        SDN - CONJUNTO NACIONAL<br>
        SALA 5067<br>
        Brasília-DF<br><br>
         
          <strong>Telefone:</strong> +55 (61) 3083-7715<br>
          <strong>WhatsApp:</strong> +55 (61) 9 9952-6183<br>
          <strong>Email:</strong> contato@solucoesambientais.net<br>
        </p>

      </div>

    </div>
  </div>

  <div class="container mt-4">
    <div class="copyright">
      &copy; <strong><span>Soluções Ambientais <?php echo date("Y"); ?></span></strong> - Todos os direitos reservados.
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/impact-bootstrap-business-website-template/ -->
      
      Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </div>
</footer><!-- End Footer -->