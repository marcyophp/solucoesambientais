<nav id="navbar" class="navbar">
  <ul>
    <li><a href="#hero">Home</a></li>
    <li><a href="#sobre">Sobre</a></li>
    <li><a href="#servicos">Serviços</a></li>
    <li><a href="#projetos">Projetos</a></li>
    <li><a href="#blog">Blog</a></li>
    <li><a href="#equipe">Equipe</a></li>
    <li><a href="#faq">FAQ</a></li>
    <li><a href="#fale">Fale conosco</a></li>
  </ul>
</nav><!-- .navbar -->